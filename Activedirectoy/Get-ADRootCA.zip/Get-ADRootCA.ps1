<#
.SYNOPSIS
  Identifies the AD/LDAPS certificate chain and root CA used by a Windows client.

.DESCRIPTION
  - Connects to a Domain Controller over LDAPS (636) and retrieves the server certificate chain.
  - Determines the root certificate and checks local trust stores (LocalMachine\Root and LocalMachine\CA).
  - Optionally also checks Global Catalog LDAPS (3269).
  - Reads Enterprise Root CAs and NTAuth from AD Configuration partition with robust byte[] handling.

.PARAMETER Domain
  AD domain FQDN. Default: $env:USERDNSDOMAIN

.PARAMETER DC
  Domain Controller to test (DNS host). Default: first discovered via _kerberos._tcp SRV.

.PARAMETER Port
  TCP port to test. Default: 636 (LDAPS). Alternative: 3269 (GC LDAPS).

.PARAMETER TryGC
  If set, also tests GC LDAPS on 3269.

.EXAMPLE
  .\Get-ADRootCA.ps1
  .\Get-ADRootCA.ps1 -DC dc01.contoso.com
  .\Get-ADRootCA.ps1 -TryGC
#>

[CmdletBinding()]
param(
  [string]$Domain = $env:USERDNSDOMAIN,
  [string]$DC,
  [int]$Port = 636,
  [switch]$TryGC
)

function Write-Section([string]$title) {
  Write-Host "`n=== $title ===" -ForegroundColor Cyan
}

function Resolve-DCs([string]$DomainFqdn) {
  $records = @()
  $names = @("_kerberos._tcp.dc._msdcs.$DomainFqdn", "_kerberos._tcp.$DomainFqdn")
  foreach ($name in $names) {
    try {
      $srv = Resolve-DnsName -Name $name -Type SRV -ErrorAction Stop
      $records += $srv | Where-Object { $_.Type -eq 'SRV' } | Select-Object -ExpandProperty NameTarget
    } catch { }
  }
  $uniq = $records | Sort-Object -Unique
  if (-not $uniq -or $uniq.Count -eq 0) {
    $fallback = ($env:LOGONSERVER -replace '^\\','')
    if ($fallback) { return @($fallback) }
  }
  return $uniq
}

function Get-RemoteTlsChain([string]$HostName, [int]$Port) {
  $tcp = New-Object System.Net.Sockets.TcpClient
  $result = [pscustomobject]@{
    Host      = $HostName
    Port      = $Port
    Connected = $false
    SslOk     = $false
    Chain     = @()
    Errors    = $null
  }
  try {
    $tcp.Connect($HostName, $Port)
    $result.Connected = $true
    $stream = $tcp.GetStream()
    # Accept any cert here; we only inspect the chain, not validate it.
    $ssl = New-Object System.Net.Security.SslStream($stream, $false, { param($s,$c,$ch,$e) $true })
    $ssl.AuthenticateAsClient($HostName)

    $result.SslOk = $true
    $remoteCert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($ssl.RemoteCertificate)

    $chain = New-Object System.Security.Cryptography.X509Certificates.X509Chain
    $chain.ChainPolicy.RevocationMode = 'NoCheck'
    [void]$chain.Build($remoteCert)

    $elements = @()
    for ($i=0; $i -lt $chain.ChainElements.Count; $i++) {
      $c = $chain.ChainElements[$i].Certificate
      $san = ($c.Extensions | Where-Object { $_.Oid.FriendlyName -eq 'Subject Alternative Name' } | ForEach-Object { $_.Format($true) }) -join '; '
      $elements += [pscustomobject]@{
        Order        = $i
        Subject      = $c.Subject
        Issuer       = $c.Issuer
        Thumbprint   = ($c.Thumbprint -replace ' ', '').ToUpper()
        NotBefore    = $c.NotBefore
        NotAfter     = $c.NotAfter
        IsSelfSigned = ($c.Subject -eq $c.Issuer)
        DnsNames     = $san
      }
    }
    $result.Chain = $elements
    $ssl.Close()
    $tcp.Close()
  } catch {
    $result.Errors = $_.Exception.Message
    try { if ($ssl) { $ssl.Close() } } catch {}
    try { if ($tcp) { $tcp.Close() } } catch {}
  }
  return $result
}

function Test-LocalStorePresence([string]$Thumb) {
  $thumb = ($Thumb -replace ' ', '').ToUpper()
  $inRoot = $false
  $inCA = $false
  try {
    $root = New-Object System.Security.Cryptography.X509Certificates.X509Store('Root','LocalMachine')
    $root.Open('ReadOnly')
    $inRoot = ($root.Certificates | Where-Object { ($_.Thumbprint -replace ' ', '').ToUpper() -eq $thumb }).Count -gt 0
    $root.Close()
  } catch {}
  try {
    $ca = New-Object System.Security.Cryptography.X509Certificates.X509Store('CA','LocalMachine')
    $ca.Open('ReadOnly')
    $inCA = ($ca.Certificates | Where-Object { ($_.Thumbprint -replace ' ', '').ToUpper() -eq $thumb }).Count -gt 0
    $ca.Close()
  } catch {}
  return [pscustomobject]@{ InLocalRoot=$inRoot; InLocalCA=$inCA }
}

function Get-ADPKIInfo {
  $out = [pscustomobject]@{
    ConfigNC          = $null
    EnterpriseRoots   = @()
    NTAuthThumbprints = @()
    Errors            = @()
  }

  function _NewCertFromBytes([object]$obj) {
    try {
      # Force proper byte[] and pass as a single argument (avoid splatting thousands of bytes)
      $raw = [byte[]]$obj
      return [System.Security.Cryptography.X509Certificates.X509Certificate2]::new(($raw))
    } catch {
      throw $_
    }
  }

  try {
    $root = [ADSI]"LDAP://RootDSE"
    $configNC = $root.configurationNamingContext
    $out.ConfigNC = $configNC

    # Enterprise Root CAs
    try {
      $caPath = "LDAP://CN=Certification Authorities,CN=Public Key Services,CN=Services,$configNC"
      $caCont = [ADSI]$caPath
      foreach ($child in $caCont.psbase.Children) {
        try {
          $bytesArr = $child.Properties['cACertificate']
          foreach ($b in $bytesArr) {
            try {
              $cert = _NewCertFromBytes $b
              $out.EnterpriseRoots += [pscustomobject]@{
                Subject    = $cert.Subject
                Issuer     = $cert.Issuer
                Thumbprint = ($cert.Thumbprint -replace ' ', '').ToUpper()
                NotAfter   = $cert.NotAfter
              }
            } catch {
              $out.Errors += "CA child parse error: $($_.Exception.Message)"
            }
          }
        } catch {
          $out.Errors += "CA container child error: $($_.Exception.Message)"
        }
      }
    } catch {
      $out.Errors += "Enterprise Roots read error: $($_.Exception.Message)"
    }

    # NTAuth
    try {
      $ntAuthPath = "LDAP://CN=NTAuthCertificates,CN=Public Key Services,CN=Services,$configNC"
      $nt = [ADSI]$ntAuthPath
      $ntBytesArr = $nt.Properties['cACertificate']
      foreach ($b in $ntBytesArr) {
        try {
          $c = _NewCertFromBytes $b
          $out.NTAuthThumbprints += (($c.Thumbprint -replace ' ', '').ToUpper())
        } catch {
          $out.Errors += "NTAuth parse error: $($_.Exception.Message)"
        }
      }
    } catch {
      $out.Errors += "NTAuth read error: $($_.Exception.Message)"
    }
  } catch {
    $out.Errors += "AD access error: $($_.Exception.Message)"
  }

  return $out
}

# --- Start ---
Write-Section "Input and discovery"
if (-not $Domain -or $Domain.Trim() -eq "") {
  throw "Could not determine domain. Provide -Domain contoso.com"
}
if (-not $DC -or $DC.Trim() -eq "") {
  $dcs = Resolve-DCs -DomainFqdn $Domain
  if ($dcs -and $dcs.Count -gt 0) {
    $DC = ($dcs | Select-Object -First 1).TrimEnd('.')
  } else {
    throw "No DC discovered via DNS and LOGONSERVER. Provide -DC."
  }
}
[pscustomobject]@{ Domain=$Domain; DC=$DC; Port=$Port } | Format-List

Write-Section "LDAPS certificate chain from DC"
$ldaps = Get-RemoteTlsChain -HostName $DC -Port $Port
if (-not $ldaps.Connected) {
  Write-Warning "TCP connect failed to $($ldaps.Host):$($ldaps.Port) - $($ldaps.Errors)"
} elseif (-not $ldaps.SslOk) {
  Write-Warning "TLS handshake failed on $($ldaps.Host):$($ldaps.Port) - $($ldaps.Errors)"
}
if ($ldaps.Chain.Count -gt 0) {
  $chainTbl = @()
  foreach ($e in $ldaps.Chain) {
    $store = Test-LocalStorePresence -Thumb $e.Thumbprint
    $chainTbl += [pscustomobject]@{
      Order        = $e.Order
      Subject      = $e.Subject
      Issuer       = $e.Issuer
      Thumbprint   = $e.Thumbprint
      NotAfter     = $e.NotAfter
      IsSelfSigned = $e.IsSelfSigned
      InLocalRoot  = $store.InLocalRoot
      InLocalCA    = $store.InLocalCA
    }
  }
  $chainTbl | Format-Table -AutoSize

  $rootElem = ($ldaps.Chain | Sort-Object Order | Select-Object -Last 1)
  if ($rootElem) {
    Write-Host "`nDetected ROOT for LDAPS chain:" -ForegroundColor Green
    [pscustomobject]@{
      RootSubject = $rootElem.Subject
      RootIssuer  = $rootElem.Issuer
      RootThumb   = $rootElem.Thumbprint
      SelfSigned  = $rootElem.IsSelfSigned
    } | Format-List
  }
} else {
  Write-Warning "No certificate chain retrieved. DC may not present an LDAPS certificate or TLS negotiation failed."
}

if ($TryGC) {
  Write-Section "Global Catalog LDAPS (3269) chain"
  $gc = Get-RemoteTlsChain -HostName $DC -Port 3269
  if ($gc.Chain.Count -gt 0) {
    $gcRoot = ($gc.Chain | Sort-Object Order | Select-Object -Last 1)
    [pscustomobject]@{
      GC_RootSubject = $gcRoot.Subject
      GC_RootIssuer  = $gcRoot.Issuer
      GC_RootThumb   = $gcRoot.Thumbprint
      GC_SelfSigned  = $gcRoot.IsSelfSigned
    } | Format-List
  } else {
    Write-Warning "No GC LDAPS chain retrieved."
  }
}

Write-Section "AD PKI (Enterprise Roots and NTAuth)"
$adpki = Get-ADPKIInfo
if ($adpki.ConfigNC) {
  Write-Host "Configuration NC: $($adpki.ConfigNC)"
}
if ($adpki.EnterpriseRoots.Count -gt 0) {
  Write-Host "`nEnterprise Root CAs advertised by AD:"
  $adpki.EnterpriseRoots | Sort-Object Subject | Format-Table Subject,Thumbprint,NotAfter -AutoSize
} else {
  Write-Warning "No Enterprise Root CAs found in AD (or access failed)."
}
if ($adpki.NTAuthThumbprints.Count -gt 0) {
  Write-Host "`nNTAuth certificate thumbprints in AD:"
  $adpki.NTAuthThumbprints | ForEach-Object { $_ }
} else {
  Write-Warning "No NTAuth entries found (or access failed)."
}
if ($adpki.Errors -and $adpki.Errors.Count -gt 0) {
  Write-Host "`nAD PKI warnings:"
  $adpki.Errors | ForEach-Object { Write-Warning $_ }
}

Write-Section "Summary"
$rootDetected = $null
if ($ldaps.Chain.Count -gt 0) {
  $rootDetected = ($ldaps.Chain | Sort-Object Order | Select-Object -Last 1)
}
$summary = [pscustomobject]@{
  Domain                 = $Domain
  DC                     = $DC
  Port                   = $Port
  LDAPS_RootSubject      = if ($rootDetected) { $rootDetected.Subject } else { $null }
  LDAPS_RootThumbprint   = if ($rootDetected) { $rootDetected.Thumbprint } else { $null }
  LDAPS_RootIsSelfSigned = if ($rootDetected) { $rootDetected.IsSelfSigned } else { $null }
  In_AD_EnterpriseRoots  = if ($rootDetected) { ($adpki.EnterpriseRoots | Where-Object { $_.Thumbprint -eq $rootDetected.Thumbprint }).Count -gt 0 } else { $false }
  In_AD_NTAuth           = if ($rootDetected) { ($adpki.NTAuthThumbprints -contains $rootDetected.Thumbprint) } else { $false }
}
$summary | Format-List

Write-Host "`nNotes:"
Write-Host " - LDAPS must be enabled and present a certificate on the DC; otherwise the remote chain cannot be built."
Write-Host " - The ROOT above is the chain root for the DC's TLS certificate. If not in LocalMachine\Root, the client will not trust LDAPS."
Write-Host " - AD 'Enterprise Root CAs' and 'NTAuth' show which CAs the domain publishes (important for smart card logon / PKINIT)."
